﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _3lesson
{
    class Program
    {

        static void Main(string[] args)
        {

            /*1.
             
            int[,] matrix = new int[3, 3];
            matrix[0, 0] = 1;
            matrix[1, 1] = 1;
            matrix[2, 2] = 1;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    System.Console.Write($"{matrix[i, j]} ");
                }
                  System.Console.WriteLine();
            } 
            */


            // 2.
         /* string[,] matrix = new string[5, 2]
            {
                {"Lucas","Lucas@gmail.com"},
                {"Benjamin","Benjamin@gmail.com"},
                {"James","James@gmail.com"},
                {"William","William@gmail.com"},
                {"Olivia","Olivia@gmail.com"}
            };
            int height = matrix.GetLength(0);
            int width = matrix.GetLength(1);
            
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Console.Write(matrix[y, x] + "\t");
                }
                Console.WriteLine();
            }
         */   



            //3.
            /* String name;
               Console.WriteLine("Enter word");
               name = Console.ReadLine();
               for (int i = name.Length - 1; i >= 0; i--) // 1 способ
               Console.Write(name[i]);
               char[] reverse = name.Reverse().ToArray(); // 2 способ
               Console.WriteLine(reverse);
            */

            //4.
            /* string[,] matrix = new string[10, 10];                      
               for (int i = 0; i < matrix.GetLength(0); i++)
               {
                   for (int j = 0; j < matrix.GetLength(1); j++)
                   {
                        matrix[i, j] = "0";                   
                   }                                              
               }
                 matrix[1, 2] = "X";
                 matrix[3, 8] = "X";
                for (int i = 0; i < matrix.GetLength(0); i++)
                {
                   for (int j = 0; j < matrix.GetLength(1); j++)
                   {
                    System.Console.Write($"{matrix[i, j]  } ");
                   }                
                  System.Console.WriteLine();
                }
               */


        }
    }
}
